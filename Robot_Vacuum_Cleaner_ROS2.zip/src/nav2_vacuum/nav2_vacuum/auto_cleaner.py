import math
from collections import deque

import rclpy
from geometry_msgs.msg import PoseStamped
from nav2_msgs.action import NavigateToPose
from nav_msgs.msg import OccupancyGrid
from rclpy.action import ActionClient
from rclpy.duration import Duration
from rclpy.node import Node
from rclpy.qos import DurabilityPolicy, QoSProfile, ReliabilityPolicy
from tf2_ros import Buffer, TransformException, TransformListener


class AutoCleaner(Node):
    def __init__(self):
        super().__init__('auto_cleaner')

        self.declare_parameter('map_frame', 'map')
        self.declare_parameter('base_frame', 'robot_vacuum/base_footprint')
        self.declare_parameter('robot_radius', 0.16)
        self.declare_parameter('clearance_margin', 0.05)
        self.declare_parameter('coverage_radius', 0.35)
        self.declare_parameter('goal_spacing', 0.35)
        self.declare_parameter('min_goal_distance', 0.25)
        self.declare_parameter('goal_timeout', 45.0)
        self.declare_parameter('planner_period', 1.0)
        self.declare_parameter('return_home', True)
        self.declare_parameter('start_enabled', False)
        self.declare_parameter('start_x', -4.0)
        self.declare_parameter('start_y', -2.0)
        self.declare_parameter('start_yaw', 0.0)

        map_qos = QoSProfile(depth=1)
        map_qos.reliability = ReliabilityPolicy.RELIABLE
        map_qos.durability = DurabilityPolicy.TRANSIENT_LOCAL
        self.map_sub = self.create_subscription(OccupancyGrid, '/map', self.map_callback, map_qos)
        self.nav_client = ActionClient(self, NavigateToPose, 'navigate_to_pose')
        self.tf_buffer = Buffer(cache_time=Duration(seconds=10.0))
        self.tf_listener = TransformListener(self.tf_buffer, self)

        self.map_msg = None
        self.active_goal = None
        self.active_goal_handle = None
        self.active_goal_start = None
        self.active_goal_id = 0
        self.covered_cells = set()
        self.blocked_cells = set()
        self.zigzag_plan = []
        self.zigzag_index = 0
        self.home_pose = None
        self.completed_goals = []
        self.return_plan = []
        self.return_index = 0
        self.returning_home = False
        self.start_reached = False
        self.finished = False
        self.active_goal_kind = None
        self.timer = self.create_timer(self.get_parameter('planner_period').value, self.control_loop)

        self.get_logger().info('Auto cleaner started: zigzag coverage through NAV2 NavigateToPose')

    def map_callback(self, msg):
        self.map_msg = msg

    def control_loop(self):
        if self.active_goal is not None:
            self.cancel_stale_goal()
            return

        pose = self.lookup_robot_pose()
        if self.map_msg is None:
            self.get_logger().info('Waiting for /map. Is nav2.launch.py or slam.launch.py running?', throttle_duration_sec=3.0)
            return
        if pose is None:
            self.get_logger().info(
                'Waiting for robot pose in map. In NAV2 mode, set 2D Pose Estimate in RViz.',
                throttle_duration_sec=3.0,
            )
            return

        start_enabled = self.get_parameter('start_enabled').value
        if self.home_pose is None and not start_enabled:
            self.home_pose = pose
            self.get_logger().info(f'Home pose saved: x={pose[0]:.2f}, y={pose[1]:.2f}')

        self.mark_current_area_covered(pose)

        if not self.nav_client.wait_for_server(timeout_sec=0.1):
            self.get_logger().warn('Waiting for NAV2 navigate_to_pose action server...', throttle_duration_sec=3.0)
            return

        target, goal_kind = self.choose_next_target(pose)
        if target is None:
            if not self.finished:
                self.get_logger().info('Cleaning mission complete.')
                self.finished = True
            return

        self.send_goal(target, pose, goal_kind)

    def send_goal(self, target, pose, goal_kind='clean'):
        goal_msg = NavigateToPose.Goal()
        goal_msg.pose = PoseStamped()
        goal_msg.pose.header.frame_id = self.get_parameter('map_frame').value
        goal_msg.pose.header.stamp = self.get_clock().now().to_msg()
        goal_msg.pose.pose.position.x = target[0]
        goal_msg.pose.pose.position.y = target[1]
        if goal_kind == 'start':
            yaw = self.get_parameter('start_yaw').value
        else:
            yaw = math.atan2(target[1] - pose[1], target[0] - pose[0])
        goal_msg.pose.pose.orientation = self.yaw_to_quaternion(yaw)

        self.active_goal = target
        self.active_goal_kind = goal_kind
        self.active_goal_start = self.get_clock().now()
        self.active_goal_id += 1
        goal_id = self.active_goal_id
        self.get_logger().info(f'{goal_kind.capitalize()} goal: x={target[0]:.2f}, y={target[1]:.2f}')
        future = self.nav_client.send_goal_async(goal_msg)
        future.add_done_callback(lambda done: self.goal_response_callback(done, goal_id, target, goal_kind))

    def goal_response_callback(self, future, goal_id, target, goal_kind):
        goal_handle = future.result()
        if not goal_handle.accepted:
            self.get_logger().warn(f'{goal_kind.capitalize()} goal rejected by NAV2')
            self.mark_goal_blocked(target)
            if goal_id == self.active_goal_id:
                self.active_goal = None
                self.active_goal_kind = None
                self.active_goal_handle = None
                self.active_goal_start = None
            return

        if goal_id != self.active_goal_id:
            goal_handle.cancel_goal_async()
            return

        self.active_goal_handle = goal_handle
        result_future = goal_handle.get_result_async()
        result_future.add_done_callback(lambda done: self.goal_result_callback(done, goal_id, target, goal_kind))

    def goal_result_callback(self, future, goal_id, target, goal_kind):
        result = future.result()
        if goal_id != self.active_goal_id:
            return

        if result.status == 4:
            self.get_logger().info(f'{goal_kind.capitalize()} goal reached')
            self.mark_world_area_covered(target)
            if goal_kind == 'start':
                self.start_reached = True
                self.home_pose = (target[0], target[1], self.get_parameter('start_yaw').value)
                self.get_logger().info(f'Home pose saved at start point: x={self.home_pose[0]:.2f}, y={self.home_pose[1]:.2f}')
            elif goal_kind == 'clean':
                self.completed_goals.append(target)
        else:
            self.get_logger().warn(f'{goal_kind.capitalize()} goal failed with status {result.status}; skipping this area')
            self.mark_goal_blocked(target)
        self.active_goal = None
        self.active_goal_kind = None
        self.active_goal_handle = None
        self.active_goal_start = None

    def choose_next_target(self, pose):
        if self.get_parameter('start_enabled').value and not self.start_reached:
            start = (self.get_parameter('start_x').value, self.get_parameter('start_y').value)
            if math.hypot(start[0] - pose[0], start[1] - pose[1]) < self.get_parameter('min_goal_distance').value:
                self.start_reached = True
                self.home_pose = (start[0], start[1], self.get_parameter('start_yaw').value)
                self.get_logger().info(f'Already at start. Home pose saved: x={start[0]:.2f}, y={start[1]:.2f}')
            else:
                return start, 'start'

        if self.returning_home:
            return self.choose_return_target(pose), 'return'

        target = self.choose_coverage_target(pose)
        if target is not None:
            return target, 'clean'

        if self.get_parameter('return_home').value and self.home_pose is not None:
            self.return_plan = list(reversed(self.completed_goals))
            self.return_plan.append((self.home_pose[0], self.home_pose[1]))
            self.return_index = 0
            self.returning_home = True
            self.get_logger().info(f'Zigzag done. Returning home through {len(self.return_plan)} reverse goals.')
            return self.choose_return_target(pose), 'return'

        return None, None

    def choose_return_target(self, pose):
        min_distance = self.get_parameter('min_goal_distance').value
        while self.return_index < len(self.return_plan):
            target = self.return_plan[self.return_index]
            self.return_index += 1
            if math.hypot(target[0] - pose[0], target[1] - pose[1]) < min_distance:
                continue
            return target

        self.returning_home = False
        return None

    def cancel_stale_goal(self):
        if self.active_goal_handle is None or self.active_goal_start is None:
            return
        goal_timeout = self.get_parameter('goal_timeout').value
        if (self.get_clock().now() - self.active_goal_start).nanoseconds <= goal_timeout * 1e9:
            return

        self.get_logger().warn('Cleaning goal timed out; canceling and skipping this area')
        self.mark_goal_blocked(self.active_goal)
        self.active_goal_handle.cancel_goal_async()
        self.active_goal_id += 1
        self.active_goal = None
        self.active_goal_kind = None
        self.active_goal_handle = None
        self.active_goal_start = None

    def choose_coverage_target(self, pose):
        if not self.zigzag_plan:
            self.zigzag_plan = self.build_zigzag_plan(pose)
            self.zigzag_index = self.closest_plan_index(pose)
            self.get_logger().info(f'Built zigzag cleaning plan with {len(self.zigzag_plan)} goals')

        min_distance = self.get_parameter('min_goal_distance').value
        while self.zigzag_index < len(self.zigzag_plan):
            target = self.zigzag_plan[self.zigzag_index]
            self.zigzag_index += 1
            cell = self.world_to_grid(target[0], target[1], self.map_msg)
            if cell is None or cell in self.blocked_cells:
                continue
            if math.hypot(target[0] - pose[0], target[1] - pose[1]) < min_distance:
                self.mark_world_area_covered(target)
                continue
            return target

        return None

    def build_zigzag_plan(self, pose):
        grid = self.map_msg
        start = self.world_to_grid(pose[0], pose[1], grid)
        if start is None:
            return []

        reachable = self.reachable_cells(start, grid)
        if not reachable:
            return []

        resolution = grid.info.resolution
        stride = max(1, int(self.get_parameter('goal_spacing').value / resolution))
        reachable_cells = {(x, y) for x, y, _ in reachable}
        min_x = min(x for x, _, _ in reachable)
        max_x = max(x for x, _, _ in reachable)
        min_y = min(y for _, y, _ in reachable)
        max_y = max(y for _, y, _ in reachable)

        rows = []
        for row_index, y in enumerate(range(min_y, max_y + 1, stride)):
            row = []
            x_range = range(min_x, max_x + 1, stride)
            if row_index % 2 == 1:
                x_range = reversed(list(x_range))

            for x in x_range:
                candidate = self.nearest_reachable_cell(x, y, reachable_cells, search_radius=max(2, stride // 2))
                if candidate is None or candidate in self.blocked_cells:
                    continue
                row.append(candidate)

            if row:
                rows.extend(row)

        return [self.grid_to_world(x, y, grid) for x, y in self.deduplicate_cells(rows)]

    def closest_plan_index(self, pose):
        if not self.zigzag_plan:
            return 0
        best_index = 0
        best_distance = float('inf')
        for index, target in enumerate(self.zigzag_plan):
            distance = math.hypot(target[0] - pose[0], target[1] - pose[1])
            if distance < best_distance:
                best_distance = distance
                best_index = index
        return best_index

    def nearest_reachable_cell(self, x, y, reachable_cells, search_radius):
        best_cell = None
        best_distance = float('inf')
        for nx in range(x - search_radius, x + search_radius + 1):
            for ny in range(y - search_radius, y + search_radius + 1):
                if (nx, ny) not in reachable_cells:
                    continue
                distance = math.hypot(nx - x, ny - y)
                if distance < best_distance:
                    best_distance = distance
                    best_cell = (nx, ny)
        return best_cell

    @staticmethod
    def deduplicate_cells(cells):
        seen = set()
        result = []
        for cell in cells:
            if cell in seen:
                continue
            seen.add(cell)
            result.append(cell)
        return result

    def reachable_cells(self, start, grid):
        width = grid.info.width
        height = grid.info.height
        resolution = grid.info.resolution
        clearance_cells = max(
            1,
            int((self.get_parameter('robot_radius').value + self.get_parameter('clearance_margin').value) / resolution),
        )

        visited = bytearray(width * height)
        queue = deque([(start[0], start[1], 0)])
        visited[self.index(start[0], start[1], width)] = 1
        reachable = []

        while queue:
            x, y, distance_steps = queue.popleft()
            reachable.append((x, y, distance_steps))
            for nx, ny in ((x + 1, y), (x - 1, y), (x, y + 1), (x, y - 1)):
                if not self.in_bounds(nx, ny, width, height):
                    continue
                idx = self.index(nx, ny, width)
                if visited[idx]:
                    continue
                visited[idx] = 1
                if self.is_traversable(nx, ny, grid, clearance_cells):
                    queue.append((nx, ny, distance_steps + 1))

        return reachable

    def lookup_robot_pose(self):
        map_frame = self.get_parameter('map_frame').value
        base_frame = self.get_parameter('base_frame').value
        try:
            transform = self.tf_buffer.lookup_transform(
                map_frame,
                base_frame,
                rclpy.time.Time(),
                timeout=Duration(seconds=0.05),
            )
        except TransformException:
            return None

        translation = transform.transform.translation
        rotation = transform.transform.rotation
        yaw = self.quaternion_to_yaw(rotation.x, rotation.y, rotation.z, rotation.w)
        return translation.x, translation.y, yaw

    def mark_current_area_covered(self, pose):
        self.mark_world_area_covered((pose[0], pose[1]))

    def mark_world_area_covered(self, point):
        if point is None or self.map_msg is None:
            return
        cell = self.world_to_grid(point[0], point[1], self.map_msg)
        if cell is None:
            return

        radius_cells = max(2, int(self.get_parameter('coverage_radius').value / self.map_msg.info.resolution))
        for x in range(cell[0] - radius_cells, cell[0] + radius_cells + 1):
            for y in range(cell[1] - radius_cells, cell[1] + radius_cells + 1):
                if self.in_bounds(x, y, self.map_msg.info.width, self.map_msg.info.height):
                    self.covered_cells.add((x, y))

    def mark_goal_blocked(self, point):
        if point is None or self.map_msg is None:
            return
        cell = self.world_to_grid(point[0], point[1], self.map_msg)
        if cell is None:
            return
        radius_cells = max(2, int(0.25 / self.map_msg.info.resolution))
        for x in range(cell[0] - radius_cells, cell[0] + radius_cells + 1):
            for y in range(cell[1] - radius_cells, cell[1] + radius_cells + 1):
                if self.in_bounds(x, y, self.map_msg.info.width, self.map_msg.info.height):
                    self.blocked_cells.add((x, y))

    def is_traversable(self, x, y, grid, clearance_cells):
        width = grid.info.width
        height = grid.info.height
        if not self.is_free_value(grid.data[self.index(x, y, width)]):
            return False

        for nx in range(x - clearance_cells, x + clearance_cells + 1):
            for ny in range(y - clearance_cells, y + clearance_cells + 1):
                if not self.in_bounds(nx, ny, width, height):
                    return False
                if math.hypot(nx - x, ny - y) > clearance_cells:
                    continue
                if grid.data[self.index(nx, ny, width)] > 50:
                    return False
        return True

    def free_count_near(self, x, y, grid, radius_cells):
        width = grid.info.width
        height = grid.info.height
        count = 0
        for nx in range(x - radius_cells, x + radius_cells + 1):
            for ny in range(y - radius_cells, y + radius_cells + 1):
                if self.in_bounds(nx, ny, width, height) and self.is_free_value(grid.data[self.index(nx, ny, width)]):
                    count += 1
        return count

    def obstacle_count_near(self, x, y, grid, radius_cells):
        width = grid.info.width
        height = grid.info.height
        count = 0
        for nx in range(x - radius_cells, x + radius_cells + 1):
            for ny in range(y - radius_cells, y + radius_cells + 1):
                if self.in_bounds(nx, ny, width, height) and grid.data[self.index(nx, ny, width)] > 50:
                    count += 1
        return count

    def world_to_grid(self, wx, wy, grid):
        origin = grid.info.origin.position
        gx = int((wx - origin.x) / grid.info.resolution)
        gy = int((wy - origin.y) / grid.info.resolution)
        if not self.in_bounds(gx, gy, grid.info.width, grid.info.height):
            return None
        return gx, gy

    def grid_to_world(self, gx, gy, grid):
        origin = grid.info.origin.position
        wx = origin.x + (gx + 0.5) * grid.info.resolution
        wy = origin.y + (gy + 0.5) * grid.info.resolution
        return wx, wy

    @staticmethod
    def is_free_value(value):
        return 0 <= value <= 30

    @staticmethod
    def in_bounds(x, y, width, height):
        return 0 <= x < width and 0 <= y < height

    @staticmethod
    def index(x, y, width):
        return y * width + x

    @staticmethod
    def quaternion_to_yaw(x, y, z, w):
        siny_cosp = 2.0 * (w * z + x * y)
        cosy_cosp = 1.0 - 2.0 * (y * y + z * z)
        return math.atan2(siny_cosp, cosy_cosp)

    @staticmethod
    def yaw_to_quaternion(yaw):
        pose = PoseStamped().pose.orientation
        pose.z = math.sin(yaw / 2.0)
        pose.w = math.cos(yaw / 2.0)
        return pose


def main(args=None):
    rclpy.init(args=args)
    node = AutoCleaner()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
