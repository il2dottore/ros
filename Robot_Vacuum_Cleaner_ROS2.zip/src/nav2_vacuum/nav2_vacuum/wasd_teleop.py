import select
import sys
import termios
import tty

import rclpy
from geometry_msgs.msg import Twist
from rclpy.node import Node


HELP = """
WASD / Arrow teleop
-------------------
W or Up       : forward
S or Down     : backward
A or Left     : turn left
D or Right    : turn right
Space         : stop
Q / Z         : speed up / slow down
E / C         : turn speed up / slow down
Ctrl-C        : quit
"""


class WasdTeleop(Node):
    def __init__(self):
        super().__init__('wasd_teleop')
        self.pub = self.create_publisher(Twist, '/cmd_vel', 10)
        self.linear_speed = 0.18
        self.angular_speed = 0.65

    def publish_cmd(self, linear, angular):
        msg = Twist()
        msg.linear.x = linear
        msg.angular.z = angular
        self.pub.publish(msg)

    def stop(self):
        self.publish_cmd(0.0, 0.0)


def read_key(settings):
    tty.setraw(sys.stdin.fileno())
    try:
        if select.select([sys.stdin], [], [], 0.1)[0]:
            key = sys.stdin.read(1)
            if key == '\x1b' and select.select([sys.stdin], [], [], 0.01)[0]:
                rest = sys.stdin.read(2)
                return key + rest
            return key
        return ''
    finally:
        termios.tcsetattr(sys.stdin, termios.TCSADRAIN, settings)


def main(args=None):
    rclpy.init(args=args)
    node = WasdTeleop()
    settings = termios.tcgetattr(sys.stdin)

    print(HELP)
    try:
        while rclpy.ok():
            key = read_key(settings)
            linear = 0.0
            angular = 0.0

            if key in ('w', 'W', '\x1b[A'):
                linear = node.linear_speed
            elif key in ('s', 'S', '\x1b[B'):
                linear = -node.linear_speed
            elif key in ('a', 'A', '\x1b[D'):
                angular = node.angular_speed
            elif key in ('d', 'D', '\x1b[C'):
                angular = -node.angular_speed
            elif key == ' ':
                node.stop()
                continue
            elif key in ('q', 'Q'):
                node.linear_speed *= 1.1
                print(f'linear={node.linear_speed:.2f}, angular={node.angular_speed:.2f}')
                continue
            elif key in ('z', 'Z'):
                node.linear_speed *= 0.9
                print(f'linear={node.linear_speed:.2f}, angular={node.angular_speed:.2f}')
                continue
            elif key in ('e', 'E'):
                node.angular_speed *= 1.1
                print(f'linear={node.linear_speed:.2f}, angular={node.angular_speed:.2f}')
                continue
            elif key in ('c', 'C'):
                node.angular_speed *= 0.9
                print(f'linear={node.linear_speed:.2f}, angular={node.angular_speed:.2f}')
                continue
            elif key == '\x03':
                break
            elif key == '':
                continue

            node.publish_cmd(linear, angular)
    finally:
        node.stop()
        termios.tcsetattr(sys.stdin, termios.TCSADRAIN, settings)
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
