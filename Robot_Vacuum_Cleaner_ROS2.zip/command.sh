sudo pkill -f "ros2 launch"
sudo pkill -f "rviz2"
sudo pkill -f "parameter_bridge"
sudo pkill -f "robot_state_publisher"
sudo pkill -f "static_transform_publisher"
sudo pkill -f "async_slam_toolbox_node"
sudo pkill -f "gz sim"
sudo pkill -f "nav2"
sudo pkill -f "auto_cleaner"
sudo pkill -f "gz sim"
sudo pkill -f "gazebo"
source /opt/ros/jazzy/setup.bash
ros2 daemon stop
ros2 daemon start

python3 -m py_compile src/nav2_vacuum/nav2_vacuum/auto_cleaner.py

colcon build --packages-select nav2_vacuum

cd ~/Documents/CD1/Robot_Vacuum_Cleaner_ROS2
source .venv/bin/activate
source /opt/ros/jazzy/setup.bash
source install/setup.bash
ros2 launch robot_description gz_custom.launch.py

cd ~/Documents/CD1/Robot_Vacuum_Cleaner_ROS2
source .venv/bin/activate
source /opt/ros/jazzy/setup.bash
source install/setup.bash
ros2 launch nav2_vacuum slam.launch.py

cd ~/Documents/CD1/Robot_Vacuum_Cleaner_ROS2
source .venv/bin/activate
source /opt/ros/jazzy/setup.bash
source install/setup.bash
ros2 run nav2_vacuum auto_cleaner --ros-args \
  -p start_enabled:=true \
  -p start_x:=-4.39587926864624 \
  -p start_y:=-2.398834228515625 \
  -p start_yaw:=0.0 \
  -p goal_timeout:=90.0

cd ~/Documents/CD1/Robot_Vacuum_Cleaner_ROS2
source .venv/bin/activate
source /opt/ros/jazzy/setup.bash
source install/setup.bash
ros2 run teleop_twist_keyboard teleop_twist_keyboard


cd ~/Documents/CD1/Robot_Vacuum_Cleaner_ROS2
source /opt/ros/jazzy/setup.bash
source install/setup.bash
ros2 run nav2_map_server map_saver_cli -f src/nav2_vacuum/maps/my_map