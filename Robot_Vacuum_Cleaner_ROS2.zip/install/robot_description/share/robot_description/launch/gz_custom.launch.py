from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, IncludeLaunchDescription, SetEnvironmentVariable
from launch.substitutions import Command, PathJoinSubstitution, LaunchConfiguration
from launch_ros.actions import Node
from launch_ros.substitutions import FindPackageShare
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch_ros.parameter_descriptions import ParameterValue
from ament_index_python.packages import get_package_share_directory
import os

def generate_launch_description():

# ================== ENVIRONMENT SETUP =================== #


    #CHANGE THESE TO BE RELEVANT TO THE SPECIFIC PACKAGE
    robot_description_path = get_package_share_directory('robot_description')  # -----> Change me!
    robot_package = FindPackageShare('robot_description') # -----> Change me!
    robot_name = 'robot_vacuum' # Verify this matches your robot's actual spawned name/tf_prefix
    robot_urdf_file_name = 'robot_vacuum.urdf.xacro'
    rviz_config_file_name = 'rviz_config.rviz'
    custom_world_file_name = 'living_room.sdf'

    parent_of_share_path = os.path.dirname(robot_description_path)

    # --- Set GZ_SIM_RESOURCE_PATH / GAZEBO_MODEL_PATH ---
    set_gz_sim_resource_path = SetEnvironmentVariable(
        name='GZ_SIM_RESOURCE_PATH', 
        value=[
            os.environ.get('GZ_SIM_RESOURCE_PATH', ''),
            os.path.pathsep, # Separator for paths
            parent_of_share_path # Add the path containing your package's share directory
        ]
    )

    # --- Use sim time setup ---
    use_sim_time_declare = DeclareLaunchArgument(
        'use_sim_time',
        default_value='true',
        description='Use simulation (Gazebo) clock if true'
    )
    spawn_x_declare = DeclareLaunchArgument('x', default_value='0', description='Robot spawn x position')
    spawn_y_declare = DeclareLaunchArgument('y', default_value='0', description='Robot spawn y position')
    spawn_z_declare = DeclareLaunchArgument('z', default_value='0.05', description='Robot spawn z position')
    spawn_yaw_declare = DeclareLaunchArgument('yaw', default_value='0', description='Robot spawn yaw angle')

    use_sim_time = LaunchConfiguration('use_sim_time')
    spawn_x = LaunchConfiguration('x')
    spawn_y = LaunchConfiguration('y')
    spawn_z = LaunchConfiguration('z')
    spawn_yaw = LaunchConfiguration('yaw')

# ========================================================= #

# ======================== RVIZ ========================== #

    # Declare arguments
    urdf_path_arg = DeclareLaunchArgument(
        'urdf_path',
        default_value=PathJoinSubstitution([
            robot_package,
            'urdf',
            robot_urdf_file_name
        ]),
        description='Path to the URDF file for the robot description.'
    )

    rviz_config_path_arg = DeclareLaunchArgument(
        'rviz_config_path',
        default_value=PathJoinSubstitution([
            robot_package,
            'rviz',
            rviz_config_file_name
        ]),
        description='Path to the RViz configuration file.'
    )

    # Get the robot description from the URDF file
    robot_description_content = ParameterValue(
        Command(['xacro ', LaunchConfiguration('urdf_path')]),
        value_type=str
    )

    # Robot State Publisher node
    robot_state_publisher_node = Node(
        package='robot_state_publisher',
        executable='robot_state_publisher',
        parameters=[{
            'robot_description': robot_description_content,
            'use_sim_time': use_sim_time,
            'frame_prefix': robot_name + '/'
        }]
    )

    # RViz2 node
    rviz2_node = Node(
        package='rviz2',
        executable='rviz2',
        name='rviz2',
        output='screen',
        arguments=['-d', LaunchConfiguration('rviz_config_path')],
        parameters=[{'use_sim_time': use_sim_time}] 
    )


# ============== GAZEBO - SETUP AND LAUNCH ================ #

    
    # Include the Gazebo Sim launch file (using gz_sim.launch.py)
    gz_sim_launch_file = PathJoinSubstitution([
        FindPackageShare('ros_gz_sim'),
        'launch',
        'gz_sim.launch.py'
    ])
    
    custom_world_path = PathJoinSubstitution([
        robot_package,
        'worlds',
        custom_world_file_name
    ])
    
    gz_args_value = ['-r ', custom_world_path]

    gazebo_launch = IncludeLaunchDescription(
        PythonLaunchDescriptionSource([gz_sim_launch_file]),
        launch_arguments={
                        'gz_args': gz_args_value,
                        'use_sim_time': use_sim_time,
                        'on_exit_shutdown': 'True'            
                        }.items()
    )

    # Reads the robot_description from the parameter server and spawns it.
    spawn_entity_node = Node(
        package='ros_gz_sim',
        executable='create',
        arguments=[
            '-name', robot_name, 
            '-topic', 'robot_description', # Read URDF from /robot_description topic
            '-x', spawn_x,
            '-y', spawn_y,
            '-z', spawn_z,
            '-Y', spawn_yaw
        ],
        output='screen'
    )

# ========================================================= #


# ================= GAZEBO BRIDGES & SENSOR SETUP =================== #

    bridge_config_file = os.path.join(robot_description_path, 'yaml', 'gazebo_bridge.yaml')

    ros_gz_bridge = Node(
        package='ros_gz_bridge',
        executable='parameter_bridge',
        name='ros_gz_bridge',
        parameters=[
            {'config_file': bridge_config_file}
        ],
        output='screen'
    )

    #THESE ARE SPECIFIC TO GETTING THE LIDAR WORKING:
    
    #publishes a static transform for the purpose of getting lidar data across to RVIZ
    lidar_tf_publisher_node = Node(
    package='tf2_ros',
    executable='static_transform_publisher',
    name='lidar_gpu_frame_broadcaster',
    output='screen',
    arguments=[
        '--x', '0', '--y', '0', '--z', '0',
        '--qx', '0', '--qy', '0', '--qz', '0', '--qw', '1',
        '--frame-id', f'{robot_name}/lidar_link',
        '--child-frame-id', f'{robot_name}/base_footprint/gpu_lidar'
    ],
    parameters=[{'use_sim_time': True}]
    )   
    
# ========================================================= #

    return LaunchDescription([
        urdf_path_arg,
        rviz_config_path_arg,
        use_sim_time_declare,
        spawn_x_declare,
        spawn_y_declare,
        spawn_z_declare,
        spawn_yaw_declare,
        set_gz_sim_resource_path, # This must come before any nodes that rely on it
        lidar_tf_publisher_node,
        robot_state_publisher_node,
        gazebo_launch,
        spawn_entity_node,
        ros_gz_bridge,
        rviz2_node
        ])
